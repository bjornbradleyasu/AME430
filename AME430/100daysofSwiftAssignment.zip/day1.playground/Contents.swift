import Cocoa

//Variables and Constants

let myFirstName = "Bjorn"

let myLastName = "Bradley"

var pointGuard = "Kyrie Irving"

var shootingGuard = "Anthony Edwards"

var smallForward = "LeBron James"

var powerForward = "Kevin Durant"

var center = "Nikola Jokic"

//Strings

let actor = "Robert Downey Jr"

print(actor.count)

let movie = "Avengers: Age of Ultron"

print(movie.uppercased())

//Store whole Number

var score = 20

let maxScore = score + 80

let minScore = score - 20

let doubleScore = score * 2

//How to store Decimal Numbers

let number = 0.1 + 0.2
print(number)

let a = 1
let b = 2.0
let c = Double(a) + b

let double1 = 3.1
let double2 = 3131.3131
let double3 = 3.0
let int1 = 3

var rating = 5.0
rating *= 2

