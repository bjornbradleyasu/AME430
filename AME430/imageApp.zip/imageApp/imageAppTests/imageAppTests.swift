//
//  imageAppTests.swift
//  imageAppTests
//
//  Created by Bjorn Bradley on 11/12/24.
//

import Testing
@testable import imageApp

struct imageAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
