//
//  imageAppApp.swift
//  imageApp
//
//  Created by Bjorn Bradley on 11/12/24.
//

import SwiftUI

@main
struct imageAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
