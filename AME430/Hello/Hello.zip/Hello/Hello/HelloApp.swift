//
//  HelloApp.swift
//  Hello
//
//  Created by Bjorn Bradley on 8/27/24.
//

import SwiftUI

@main
struct HelloApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
