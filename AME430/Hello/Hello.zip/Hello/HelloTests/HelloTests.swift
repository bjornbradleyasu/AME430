//
//  HelloTests.swift
//  HelloTests
//
//  Created by Bjorn Bradley on 8/27/24.
//

import Testing

struct HelloTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
