//
//  movieAppTests.swift
//  movieAppTests
//
//  Created by Bjorn Bradley on 12/9/24.
//

import Testing
@testable import movieApp

struct movieAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
