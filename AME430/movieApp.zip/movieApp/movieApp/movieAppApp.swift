//
//  movieAppApp.swift
//  movieApp
//
//  Created by Bjorn Bradley on 12/9/24.
//

import SwiftUI

@main
struct movieAppApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView() // Use the new HomeView as the starting point
        }
    }
}
