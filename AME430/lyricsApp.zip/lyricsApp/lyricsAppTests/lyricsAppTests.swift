//
//  lyricsAppTests.swift
//  lyricsAppTests
//
//  Created by Bjorn Bradley on 10/27/24.
//

import Testing
@testable import lyricsApp

struct lyricsAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
