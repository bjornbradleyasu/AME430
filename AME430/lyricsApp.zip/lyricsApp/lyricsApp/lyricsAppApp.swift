//
//  lyricsAppApp.swift
//  lyricsApp
//
//  Created by Bjorn Bradley on 10/27/24.
//

import SwiftUI

@main
struct lyricsAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
